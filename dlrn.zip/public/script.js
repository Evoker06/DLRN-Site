const $ = s => document.querySelector(s);
const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
const get = (o, p) => p.split(".").reduce((a, k) => a?.[k], o);
const safeUrl = u => /^(https?:\/\/|\/uploads\/)/.test(u) ? u : "#";
const onlineEl = $("#online"), heroOnlineEl = $("#heroOnline"), toast = $("#toast");
let C, IP = "";

function tok(node, text) {
  String(text).split(/(\{ip\}|\{version\})/).forEach(s => {
    if (s === "{ip}") node.append(el("strong", "", IP));
    else if (s === "{version}") node.append(el("strong", "ver", "—"));
    else if (s) node.append(s);
  });
}
function lines(node, text) {
  String(text).split("\n").forEach((l, i) => {
    if (i) node.append(document.createElement("br"));
    node.append(l);
  });
}
function link(cls, url, label) {
  const a = el("a", cls); a.href = safeUrl(url); a.target = "_blank"; a.rel = "noopener";
  a.append(label + " "); a.append(el("span", "", "↗")); return a;
}
function block(title, text, inline) {
  const p = el("p"); p.append("● ", el("strong", "", title));
  if (text) { if (inline) p.append(" "); else p.append(document.createElement("br")); lines(p, text); }
  return p;
}

/* ===== Дополнительное содержимое (блоки из админки) ===== */
const FONTS = { serif: 'Georgia, "Times New Roman", serif', mono: 'ui-monospace, Menlo, Consolas, monospace' };
function inline(node, text) {
  String(text).split(/(\*\*[^*\n]+\*\*|\*[^*\n]+\*|\[[^\]\n]+\]\((?:https?:\/\/|\/uploads\/)[^)\s]+\))/).forEach((s, i) => {
    if (!s) return;
    if (!(i % 2)) return node.append(s);
    let m;
    if (s.startsWith("**")) node.append(el("strong", "", s.slice(2, -2)));
    else if (s[0] === "*") node.append(el("em", "", s.slice(1, -1)));
    else if ((m = s.match(/^\[([^\]]+)\]\(([^)]+)\)$/))) {
      const a = el("a", "blk-link", m[1]); a.href = safeUrl(m[2]); a.target = "_blank"; a.rel = "noopener"; node.append(a);
    } else node.append(s);
  });
}
function rich(node, text) {
  String(text).split("\n").forEach((l, i) => { if (i) node.append(document.createElement("br")); inline(node, l); });
}
const HEX = /^#[0-9a-f]{6}$/i;
const STYLED = new Set(["heading", "paragraph", "quote", "callout", "ul", "ol", "table"]);
function embedUrl(u) {
  let m;
  if ((m = u.match(/^https?:\/\/(?:www\.|m\.)?youtube\.com\/watch\?(?:[^#]*&)?v=([\w-]{11})/)) ||
      (m = u.match(/^https?:\/\/youtu\.be\/([\w-]{11})/)) ||
      (m = u.match(/^https?:\/\/(?:www\.)?youtube\.com\/(?:embed|shorts)\/([\w-]{11})/)))
    return "https://www.youtube-nocookie.com/embed/" + m[1];
  if ((m = u.match(/^https?:\/\/(?:www\.)?vimeo\.com\/(\d+)/))) return "https://player.vimeo.com/video/" + m[1];
  return "";
}
function blockEl(b) {
  let n;
  switch (b.type) {
    case "heading": n = el("h" + Math.min(6, Math.max(1, +b.level || 2)), "blk"); inline(n, b.text); break;
    case "paragraph": n = el("p", "blk"); rich(n, b.text); break;
    case "quote":
      n = el("blockquote", "blk blk-quote"); const q = el("p"); rich(q, b.text); n.append(q);
      if (b.author) n.append(el("div", "blk-cite", "— " + b.author));
      break;
    case "callout": {
      const v = ["info", "success", "warning", "danger"].includes(b.variant) ? b.variant : "info";
      n = el("div", "blk blk-callout v-" + v);
      if (b.title) n.append(el("strong", "blk-callout-title", b.title));
      const p = el("p"); rich(p, b.text); n.append(p); break;
    }
    case "ul": case "ol":
      n = el(b.type, "blk");
      (b.items || []).filter(x => String(x).trim()).forEach(x => { const li = el("li"); inline(li, x); n.append(li); });
      break;
    case "table": {
      n = el("div", "blk blk-table"); const t = el("table");
      if ((b.header || []).some(Boolean)) {
        const tr = el("tr"); b.header.forEach(c => { const th = el("th"); inline(th, c); tr.append(th); });
        const th = el("thead"); th.append(tr); t.append(th);
      }
      const tb = el("tbody");
      (b.rows || []).forEach(r => { const tr = el("tr"); r.forEach(c => { const td = el("td"); inline(td, c); tr.append(td); }); tb.append(tr); });
      t.append(tb); n.append(t); break;
    }
    case "image": n = el("img", "blk"); n.src = safeUrl(b.url); n.alt = b.alt || ""; n.loading = "lazy"; break;
    case "file": n = link("contact-btn blk", b.url, "⬇ " + (b.label || "Файл"));
      if (/^\/uploads\//.test(b.url)) n.setAttribute("download", ""); break;
    case "link": n = link("contact-btn blk", b.url, b.label || "Ссылка"); break;
    case "video": {
      n = el("figure", "blk blk-video");
      const e = embedUrl(b.url || "");
      if (e) {
        const w = el("div", "blk-ratio"), f = document.createElement("iframe");
        f.src = e; f.title = b.title || "Видео"; f.loading = "lazy"; f.allowFullscreen = true;
        f.setAttribute("allow", "fullscreen; picture-in-picture"); f.referrerPolicy = "strict-origin-when-cross-origin";
        w.append(f); n.append(w);
      } else {
        const v = document.createElement("video");
        v.controls = true; v.preload = "metadata"; v.playsInline = true; v.src = safeUrl(b.url || ""); n.append(v);
      }
      if (b.title) n.append(el("figcaption", "blk-cite", b.title));
      break;
    }
    default: return document.createComment("");
  }
  // оформление и размещение
  if (HEX.test(b.bg || "")) { n.style.backgroundColor = b.bg; n.classList.add("has-bg"); }
  const widthSet = ["75", "50", "33"].includes(String(b.width));
  if (widthSet) n.style.width = b.width + "%";
  const sides = { left: "flex-start", center: "center", right: "flex-end" };
  if (sides[b.align]) {
    n.style.textAlign = b.align;
    if (widthSet || ["image", "video", "file", "link"].includes(b.type)) n.style.alignSelf = sides[b.align];
  } else if (widthSet) n.style.alignSelf = "flex-start";
  if (STYLED.has(b.type)) {
    if (FONTS[b.font]) n.style.fontFamily = FONTS[b.font];
    if (/^\d{2}$/.test(b.size)) n.style.fontSize = b.size + "px";
    if (HEX.test(b.color || "")) { n.style.setProperty("--bc", b.color); n.classList.add("has-color"); }
  }
  return n;
}
// Вставка блоков: top/bottom — [узел, способ вставки] для блоков «над» и «под» основным содержимым
function putAt(blocks, top, bottom) {
  if (!Array.isArray(blocks) || !blocks.length) return;
  [[top, "top"], [bottom, "bottom"]].forEach(([at, pos]) => {
    const list = blocks.filter(b => (b.pos === "top" ? "top" : "bottom") === pos);
    if (!list.length || !at || !at[0]) return;
    const d = el("div", "blocks" + (pos === "top" ? " blocks-top" : ""));
    list.forEach(b => { try { d.append(blockEl(b)); } catch (e) { console.error(e); } });
    at[0][at[1]](d);
  });
}
function renderBlocks() {
  putAt(C.hero.blocks, [$(".hero-copy"), "prepend"], [$(".hero-text"), "after"]);
  putAt(C.about.blocks, [$("#aboutText"), "prepend"], [$("#aboutText"), "append"]);
  putAt(C.features.blocks, [$("#features h2"), "after"], [$("#features"), "append"]);
  putAt(C.join.blocks, [$(".join-inner p"), "before"], [$(".join-inner p"), "after"]);
  putAt(C.rules.discord.blocks, [$("#discordRules h3"), "after"], [$("#discordRules"), "append"]);
  putAt(C.rules.minecraft.blocks, [$("#mcRules h3"), "after"], [$("#mcRules"), "append"]);
  putAt(C.rules.blocks, [$("#rules h2"), "after"], [$("#warning"), "before"]);
  putAt(C.faq.blocks, [$("#faq h2"), "after"], [$("#faq"), "append"]);
  putAt(C.footer.blocks, [$(".footer-main p"), "before"], [$(".footer-main p"), "after"]);
}
// Порядок, видимость и цвета разделов + собственные разделы
const SECTION_SEL = { hero: ".hero", stats: ".stats", project: "#project", features: "#features", join: "#join", rules: "#rules", faq: "#faq" };
function applyLayout() {
  const main = $("main"), L = C.layout || {}, hidden = new Set(L.hidden || []), custom = {};
  (C.sections || []).forEach(s => {
    const sec = el("section", "section custom-section"), body = el("div", "custom-body");
    sec.id = s.id;
    if (s.title) sec.append(el("h2", "", s.title));
    sec.append(body); putAt(s.blocks, [body, "append"], [body, "append"]);
    if (HEX.test(s.bg || "")) sec.style.backgroundColor = s.bg;
    if (s.nav && s.title) {
      const a = el("a", "", s.title); a.href = "#" + s.id;
      a.addEventListener("click", () => document.getElementById("nav").classList.remove("open"));
      document.getElementById("nav").append(a);
    }
    custom[s.id] = sec;
  });
  (L.order || []).forEach(id => {
    const e = SECTION_SEL[id] ? $(SECTION_SEL[id]) : custom[id];
    if (!e) return;
    main.append(e);
    if (HEX.test(L.colors?.[id] || "")) e.style.backgroundColor = L.colors[id];
  });
  hidden.forEach(id => {
    const e = SECTION_SEL[id] ? $(SECTION_SEL[id]) : custom[id];
    if (e) e.style.display = "none";
    document.querySelectorAll(`#nav a[href="#${id}"], .footer-links a[href="#${id}"]`).forEach(a => a.style.display = "none");
  });
  if (HEX.test(L.colors?.footer || "")) $("footer").style.backgroundColor = L.colors.footer;
}

function render() {
  document.title = C.site.title;
  IP = C.site.ip;
  document.querySelectorAll("[data-t]").forEach(e => e.textContent = get(C, e.dataset.t) ?? "");

  const about = $("#aboutText");
  about.replaceChildren(...C.about.paragraphs.map(t => el("p", "", t)));

  $("#socials").replaceChildren(...C.socials.map(s => {
    const a = el("a", "social-link");
    a.href = safeUrl(s.url); a.target = "_blank"; a.rel = "noopener";
    const l = el("span");
    l.append(el("b", "", s.name), el("small", "", s.desc));
    a.append(l, el("span", "", "↗"));
    return a;
  }));

  $("#cards").replaceChildren(...C.features.items.map(f => {
    const c = el("article", "feature-card");
    c.append(el("div", "icon", f.icon), el("h3", "", f.title), el("p", "", f.text));
    if (HEX.test(f.bg || "")) c.style.backgroundColor = f.bg;
    putAt(f.blocks, [c, "prepend"], [c, "append"]);
    return c;
  }));

  const d = C.rules.discord, dr = $("#discordRules");
  dr.replaceChildren(el("h3", "", d.title), ...d.items.map(i => block(i.title, i.text, i.inline)));

  const m = C.rules.minecraft, mr = $("#mcRules"), basic = el("p");
  m.basic.forEach((t, i) => {
    if (i) basic.append(document.createElement("br"));
    basic.append("● ", el("strong", "", t));
  });
  const det = el("details", "mods-details"), sum = el("summary"), ol = el("ol", "mods-list");
  sum.append(m.mods.listLabel + " ", el("span", "", "+"));
  m.mods.list.forEach(x => {
    const li = el("li"); li.append(el("b", "", x.name));
    if (x.note) li.append(" — " + x.note);
    ol.append(li);
  });
  det.append(sum, ol);
  const bugs = block(m.bugs.title, m.bugs.text);
  bugs.append(" ", link("contact-btn rules-btn", m.bugs.buttonUrl, m.bugs.buttonLabel));
  const farms = block(m.farms.title, m.farms.items.join("\n"));
  mr.replaceChildren(el("h3", "", m.title), basic, block(m.mods.title, m.mods.text), det, bugs,
                     block(m.chat.title, m.chat.text), farms);

  $("#warning").replaceChildren(...C.rules.warning.map(t => el("div", "", "−  " + t)));

  const faq = $("#faqList");
  faq.replaceChildren(...C.faq.items.map((it, i) => {
    const dt = el("details"); if (i === 0) dt.open = true;
    const sm = el("summary"); sm.append(it.q, el("span", "", "+")); dt.append(sm);
    if (it.a) { const p = el("p"); tok(p, it.a); dt.append(p); }
    if (it.buttons && it.buttons.length) {
      const b = el("div", "contact-buttons");
      it.buttons.forEach(x => b.append(link("contact-btn", x.url, x.label)));
      dt.append(b);
    }
    if (HEX.test(it.bg || "")) dt.style.backgroundColor = it.bg;
    putAt(it.blocks, [sm, "after"], [dt, "append"]);
    return dt;
  }));
}

function setOnline(n) { onlineEl.textContent = n; heroOnlineEl.textContent = n; }
function cleanVersion(value) {
  if (!value) return "—";
  const matches = String(value).trim().match(/\b\d+(?:\.\d+){1,3}\b/g);
  return matches?.[matches.length - 1] || String(value).trim();
}
function setVersion(value) {
  const v = cleanVersion(value);
  document.querySelectorAll(".ver").forEach(e => e.textContent = v);
}
async function fetchStatus() {
  try {
    const r = await fetch(`https://api.mcsrvstat.us/3/${encodeURIComponent(IP)}`, { cache: "no-store" });
    if (!r.ok) throw 0;
    const data = await r.json();
    setOnline(data.online ? (data.players?.online ?? 0) : 0);
    setVersion(data.version);
  } catch { setOnline("—"); setVersion("—"); }
}

async function copyIP() {
  try { await navigator.clipboard.writeText(IP); }
  catch {
    const a = document.createElement("textarea"); a.value = IP;
    document.body.appendChild(a); a.select(); document.execCommand("copy"); a.remove();
  }
  toast.classList.add("show"); setTimeout(() => toast.classList.remove("show"), 1800);
}
$("#copyIp").addEventListener("click", copyIP);
$("#copyJoin").addEventListener("click", () => {
  copyIP();
  $("#copyMessage").textContent = "Скопировано!";
  setTimeout(() => $("#copyMessage").textContent = "", 1800);
});

fetch("/api/content", { cache: "no-store" })
  .then(async r => {
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || ("HTTP " + r.status));
    return j;
  })
  .then(c => {
    C = c;
    render();
    renderBlocks();
    applyLayout();
    fetchStatus();
    setInterval(fetchStatus, 30000);
    if (location.hash) document.getElementById(location.hash.slice(1))?.scrollIntoView();
  })
  .catch(err => {
    console.error(err);
    const box = document.createElement("div");
    box.style.cssText = "position:fixed;top:0;left:0;right:0;background:#2a1215;color:#ff6b6b;padding:10px 16px;font:14px/1.4 Inter,Arial,sans-serif;z-index:999;text-align:center";
    box.textContent = "Не удалось загрузить содержимое сайта (" + (err.message || err) + "). Проверьте, что запущен server.js.";
    document.body.appendChild(box);
  });

const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");
menuBtn.addEventListener("click", () => nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

const topBtn = document.getElementById("topBtn");
window.addEventListener("scroll", () => topBtn.classList.toggle("show", scrollY > 500));
topBtn.addEventListener("click", () => scrollTo({ top: 0, behavior: "smooth" }));

const head = document.getElementById("minecraftHead");
const headSpeech = document.getElementById("headSpeech");
let typingTimer;
head.addEventListener("click", () => {
  clearInterval(typingTimer);
  headSpeech.textContent = "";
  headSpeech.classList.add("show");
  let index = 0;
  const phrase = C?.hero?.headPhrase || "";
  typingTimer = setInterval(() => {
    headSpeech.textContent = phrase.slice(0, index++);
    if (index > phrase.length) {
      clearInterval(typingTimer);
      setTimeout(() => headSpeech.classList.remove("show"), 3500);
    }
  }, 55);
});