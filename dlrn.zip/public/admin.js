const $ = s => document.querySelector(s);
const L = {site:"Сайт",title:"Заголовок",ip:"IP сервера",hero:"Главный экран",eyebrow:"Надпись над заголовком",title1:"Заголовок, строка 1",title2:"Заголовок, строка 2",text:"Текст",headPhrase:"Фраза, которую печатает голова",
  about:"О проекте",paragraphs:"Абзацы",socials:"Соцсети",name:"Название",desc:"Описание",url:"Ссылка (https://…)",features:"Возможности",items:"Элементы",icon:"Иконка",
  join:"Блок «Присоединиться»",rules:"Правила",discord:"Правила Discord",inline:"Текст в той же строке",minecraft:"Правила Minecraft",basic:"Основные правила",
  mods:"Запрещённые модификации",listLabel:"Подпись раскрывающегося списка",list:"Список модов",note:"Пояснение",bugs:"Баги и недоработки",buttonLabel:"Текст кнопки",buttonUrl:"Ссылка кнопки",
  chat:"Чат сервера",farms:"Запрещённые фермы",warning:"Предупреждение (строки)",faq:"FAQ",q:"Вопрос",a:"Ответ ({ip} и {version} подставляются сами)",buttons:"Кнопки",label:"Текст кнопки",
  footer:"Подвал",copyright:"Копирайт",right:"Справа"};
const TPL = {buttons:{label:"", url:"https://"}};
const lab = k => L[k] || k;

let data, ORIGINAL;
const api = (m, u, b) => fetch(u, {method:m, headers:{"Content-Type":"application/json","X-Requested-With":"fetch"}, body:b && JSON.stringify(b)});
const blank = v => Array.isArray(v) ? []
  : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, blank(x)]))
  : typeof v === "boolean" ? false : "";
const mk = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };

function input(obj, k) {
  const v = obj[k];
  if (typeof v === "boolean") { const i = mk("input"); i.type = "checkbox"; i.checked = v; i.onchange = () => obj[k] = i.checked; return i; }
  const str = typeof v === "string" ? v : String(v ?? "");
  const multi = str.length > 70 || str.includes("\n");
  const i = mk(multi ? "textarea" : "input");
  i.value = str; i.oninput = () => obj[k] = i.value; return i;
}

function build(parent, obj, refObj) {
  Object.keys(obj).forEach(k => {
    if (obj === data && (k === "layout" || k === "sections")) return;
    if (k === "blocks") { parent.append(blocksEditor(obj, k)); return; }
    if (k === "bg") { parent.append(fld("Цвет контейнера", colorField(obj, k))); return; }
    const v = obj[k];
    const ref = refObj ? refObj[k] : undefined;
    if (Array.isArray(v)) parent.append(list(obj, k, ref));
    else if (v && typeof v === "object") {
      const f = mk("fieldset"); f.append(mk("legend", "", lab(k)));
      build(f, v, ref); parent.append(f);
    } else {
      const w = mk("div"); w.append(mk("label", "", lab(k))); w.append(input(obj, k)); parent.append(w);
    }
  });
}

function list(obj, k, refArr) {
  const arr = obj[k], f = mk("fieldset");
  f.append(mk("legend", "", lab(k)));
  arr.forEach((it, i) => {
    const prim = typeof it === "string";
    const box = prim ? mk("div", "row") : mk("fieldset");
    if (prim) box.append(input(arr, i));
    else build(box, it, refArr && (refArr[i] ?? refArr[0]));
    const tools = mk("div", prim ? "" : "tools");
    [["↑", () => i > 0 && ([arr[i-1], arr[i]] = [arr[i], arr[i-1]])],
     ["↓", () => i < arr.length-1 && ([arr[i+1], arr[i]] = [arr[i], arr[i+1]])],
     ["✕", () => arr.splice(i, 1)]]
      .forEach(([t, fn]) => {
        const b = mk("button", "mini", t);
        b.type = "button";
        b.onclick = () => { fn(); draw(); };
        tools.append(b);
      });
    box.append(tools); f.append(box);
  });
  const add = mk("button", "mini", "+ Добавить");
  add.type = "button";
  add.onclick = () => {
    const sample = refArr && refArr[0];
    arr.push(sample !== undefined ? blank(sample) : (TPL[k] ? {...TPL[k]} : ""));
    draw();
  };
  f.append(add); return f;
}

/* ===== Редактор дополнительного содержимого (блоков) ===== */
const BTYPES = {heading:"Заголовок (H1–H6)",paragraph:"Абзац",quote:"Цитата",callout:"Врезка / плашка",ul:"Маркированный список",ol:"Нумерованный список",table:"Таблица",image:"Изображение",file:"Файл для скачивания",link:"Ссылка-кнопка",video:"Видео (файл или ссылка)"};
const STYLED = new Set(["heading","paragraph","quote","callout","ul","ol","table"]);
const BNEW = {
  heading:()=>({type:"heading",level:2,text:"",font:"",size:""}),
  paragraph:()=>({type:"paragraph",text:"",font:"",size:""}),
  quote:()=>({type:"quote",text:"",author:"",font:"",size:""}),
  callout:()=>({type:"callout",variant:"info",title:"",text:"",font:"",size:""}),
  ul:()=>({type:"ul",items:[""],font:"",size:""}),
  ol:()=>({type:"ol",items:[""],font:"",size:""}),
  table:()=>({type:"table",header:["",""],rows:[["",""]],font:"",size:""}),
  image:()=>({type:"image",url:"",alt:""}),
  file:()=>({type:"file",label:"",url:""}),
  link:()=>({type:"link",label:"",url:"https://"}),
  video:()=>({type:"video",url:"",title:""})
};
// общие поля оформления и размещения у каждого блока
Object.keys(BNEW).forEach(t => {
  const mkBlock = BNEW[t];
  BNEW[t] = () => ({...mkBlock(), pos:"bottom", align:"", width:"", bg:"", ...(STYLED.has(t) ? {color:""} : {})});
});

const fld = (label, node) => { const w = mk("div"); w.append(mk("label", "", label), node); return w; };
const txt = (b, k, multi, ph) => { const i = mk(multi ? "textarea" : "input"); i.value = b[k] ?? ""; if (ph) i.placeholder = ph; i.oninput = () => b[k] = i.value; return i; };
const sel = (b, k, opts, num) => {
  const s = mk("select");
  opts.forEach(([v, t]) => { const o = mk("option", "", t); o.value = v; s.append(o); });
  s.value = String(b[k] ?? opts[0][0]); s.onchange = () => b[k] = num ? Number(s.value) : s.value; return s;
};

async function upload(file) {
  const r = await fetch("/api/upload", {method:"POST",
    headers:{"X-Requested-With":"fetch","X-Filename":encodeURIComponent(file.name),"Content-Type":"application/octet-stream"}, body:file});
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) throw new Error("Сессия истекла, войдите заново");
  if (!r.ok) throw new Error(j.error || "Ошибка загрузки");
  return j.url;
}
function picker(accept, cb) {
  const f = mk("input"); f.type = "file"; if (accept) f.accept = accept;
  f.onchange = async () => {
    const file = f.files[0]; if (!file) return;
    const m = $("#msg"); m.style.color = ""; m.textContent = "Загрузка файла… (видео может грузиться долго, не закрывайте страницу)";
    try { cb(await upload(file), file); m.textContent = "Файл загружен ✓ (не забудьте «Сохранить»)"; m.style.color = "#6ee7a0"; }
    catch (e) { m.textContent = e.message; m.style.color = "#ff5a64"; }
  };
  f.click();
}
function urlField(b, k, accept) {
  const row = mk("div", "row"), i = txt(b, k, false, "https://… или загрузите файл");
  const up = mk("button", "mini", "⬆ Загрузить"); up.type = "button";
  up.onclick = () => picker(accept, (u, f) => {
    b[k] = u; if ("label" in b && !b.label) b.label = f.name; if ("alt" in b && !b.alt) b.alt = f.name; if ("title" in b && !b.title) b.title = f.name; draw();
  });
  row.append(i, up); return row;
}
function rich(b, k, ph) {
  const w = mk("div"), ta = txt(b, k, true, ph || "Текст"), bar = mk("div", "fmt");
  const wrap = (l, r, def) => {
    const s = ta.selectionStart, e = ta.selectionEnd;
    ta.setRangeText(l + (ta.value.slice(s, e) || def) + r, s, e, "select");
    ta.dispatchEvent(new Event("input")); ta.focus();
  };
  const btn = (t, title, fn) => { const x = mk("button", "mini", t); x.type = "button"; x.title = title; x.onclick = fn; bar.append(x); return x; };
  btn("Ж", "Жирный", () => wrap("**", "**", "текст")).style.fontWeight = "800";
  btn("К", "Курсив", () => wrap("*", "*", "текст")).style.fontStyle = "italic";
  btn("🔗 Ссылка", "Вставить ссылку", () => { const u = prompt("Адрес ссылки (https://…)", "https://"); if (u) wrap("[", "](" + u.replace(/\s/g, "") + ")", "текст ссылки"); });
  btn("⬆ Файл", "Загрузить файл и вставить ссылку на него", () => picker("", (u, f) => wrap("[", "](" + u + ")", f.name)));
  w.append(bar, ta); return w;
}
function listForm(box, b) {
  const t = mk("textarea"); t.value = b.items.join("\n"); t.oninput = () => b.items = t.value.split("\n");
  box.append(fld("Каждый пункт — с новой строки (можно **жирный**, *курсив*, [ссылка](https://…))", t));
}
const linkForm = (box, b) => box.append(fld("Название", txt(b, "label")), fld("Ссылка или файл", urlField(b, "url", "")));
const BFORM = {
  heading:(box, b) => box.append(fld("Уровень", sel(b, "level", [1,2,3,4,5,6].map(n => [n, "H" + n]), true)), fld("Текст заголовка", txt(b, "text"))),
  paragraph:(box, b) => box.append(fld("Текст абзаца", rich(b, "text", "Текст абзаца. Выделите слово и нажмите Ж или К"))),
  quote:(box, b) => box.append(fld("Цитата", rich(b, "text")), fld("Автор (необязательно)", txt(b, "author"))),
  callout:(box, b) => box.append(
    fld("Вид плашки", sel(b, "variant", [["info","Информация"],["success","Подсказка"],["warning","Внимание"],["danger","Важно"]])),
    fld("Заголовок плашки", txt(b, "title")), fld("Текст", rich(b, "text"))),
  ul:listForm, ol:listForm,
  table:(box, b) => {
    const t = mk("textarea"); t.value = [b.header, ...b.rows].map(r => r.join(" | ")).join("\n");
    t.placeholder = "Характеристика | Значение\nВерсия | 1.21";
    t.oninput = () => { const L = t.value.split("\n").map(l => l.split("|").map(c => c.trim())); b.header = L[0]; b.rows = L.slice(1).filter(r => r.some(Boolean)); };
    box.append(fld("Таблица: первая строка — заголовки, столбцы разделяйте символом |", t));
  },
  image:(box, b) => {
    box.append(fld("Ссылка на изображение или файл", urlField(b, "url", "image/*")), fld("Описание (alt)", txt(b, "alt")));
    if (b.url) { const im = mk("img", "pv"); im.src = b.url; box.append(im); }
  },
  file:linkForm, link:linkForm,
  video:(box, b) => box.append(
    fld("Ссылка на видео (YouTube, Vimeo или прямая ссылка на файл) либо загрузка файла mp4/webm", urlField(b, "url", "video/mp4,video/webm")),
    fld("Подпись под видео (необязательно)", txt(b, "title")))
};
function styleRow(b) {
  const g = mk("div", "two"), z = mk("input");
  z.type = "number"; z.min = 10; z.max = 96; z.placeholder = "авто"; z.value = b.size || "";
  z.oninput = () => b.size = z.value === "" ? "" : String(Math.min(96, Math.max(10, Math.round(+z.value) || 10)));
  g.append(fld("Шрифт", sel(b, "font", [["","По умолчанию"],["serif","С засечками"],["mono","Моноширинный"]])), fld("Размер текста, px (10–96)", z));
  return g;
}
function blockTools(arr, i) {
  const t = mk("div", "tools");
  [["↑", () => i > 0 && ([arr[i-1], arr[i]] = [arr[i], arr[i-1]])],
   ["↓", () => i < arr.length-1 && ([arr[i+1], arr[i]] = [arr[i], arr[i+1]])],
   ["✕", () => arr.splice(i, 1)]].forEach(([s, fn]) => {
    const x = mk("button", "mini", s); x.type = "button"; x.onclick = () => { fn(); draw(); }; t.append(x);
  });
  const mv = mk("select"); mv.title = "Переместить блок в другой контейнер на сайте";
  mv.append(new Option("Переместить в…", ""));
  const all = containers(); all.forEach(([l], j) => mv.append(new Option(l, j)));
  mv.onchange = () => {
    if (mv.value === "") return;
    const to = all[+mv.value][1];
    if (to === arr) { mv.value = ""; return; }
    to.push(arr.splice(i, 1)[0]); draw();
  };
  t.prepend(mv);
  return t;
}
function blocksEditor(obj, k) {
  const arr = obj[k], f = mk("fieldset", "blocks-ed");
  f.append(mk("legend", "", "＋ Дополнительное содержимое"));
  f.append(mk("small", "hint", "Контейнер для текста, файлов и ссылок. Блоки появятся на сайте в этом месте."));
  arr.forEach((b, i) => {
    const box = mk("fieldset"); box.append(mk("legend", "", (i + 1) + ". " + (BTYPES[b.type] || b.type)));
    if (BFORM[b.type]) BFORM[b.type](box, b);
    const det = mk("details"); det.append(mk("summary", "", "Оформление и размещение"));
    if (STYLED.has(b.type)) det.append(styleRow(b));
    det.append(viewRow(b)); box.append(det);
    box.append(blockTools(arr, i)); f.append(box);
  });
  const bar = mk("div", "row"), s = mk("select");
  Object.entries(BTYPES).forEach(([v, t]) => { const o = mk("option", "", t); o.value = v; s.append(o); });
  const add = mk("button", "mini", "+ Добавить блок"); add.type = "button";
  add.onclick = () => { arr.push(BNEW[s.value]()); draw(); };
  bar.append(s, add); f.append(bar); return f;
}


/* ===== Цвета, размещение, структура страницы ===== */
function colorField(obj, k) {
  const row = mk("div", "row colorf"), c = mk("input"), t = mk("span", "cv"), x = mk("button", "mini", "Сбросить");
  c.type = "color"; x.type = "button";
  const show = () => { c.value = /^#[0-9a-f]{6}$/i.test(obj[k] || "") ? obj[k] : "#000000"; t.textContent = obj[k] || "не задан"; };
  c.oninput = () => { obj[k] = c.value; t.textContent = c.value; };
  x.onclick = () => { obj[k] = ""; show(); };
  show(); row.append(c, t, x); return row;
}
function viewRow(b) {
  const g = mk("div", "two");
  g.append(
    fld("Положение в контейнере", sel(b, "pos", [["bottom","Под основным содержимым"],["top","Над основным содержимым"]])),
    fld("Выравнивание", sel(b, "align", [["","По умолчанию"],["left","Слева"],["center","По центру"],["right","Справа"]])),
    fld("Ширина", sel(b, "width", [["","На всю ширину"],["75","75%"],["50","50%"],["33","33%"]])),
    fld("Цвет контейнера (фон)", colorField(b, "bg")));
  if (STYLED.has(b.type)) g.append(fld("Цвет текста", colorField(b, "color")));
  return g;
}
// Все контейнеры, куда можно переместить блок
function containers() {
  const out = [], C = data, add = (l, a) => Array.isArray(a) && out.push([l, a]);
  add("Главный экран", C.hero.blocks); add("О проекте", C.about.blocks);
  add("Возможности (раздел)", C.features.blocks);
  C.features.items.forEach((f, i) => add("Карточка: " + (f.title || i + 1), f.blocks));
  add("Присоединиться", C.join.blocks); add("Правила (раздел)", C.rules.blocks);
  add("Правила Discord", C.rules.discord.blocks); add("Правила Minecraft", C.rules.minecraft.blocks);
  add("FAQ (раздел)", C.faq.blocks);
  C.faq.items.forEach((f, i) => add("Вопрос: " + (f.q || i + 1), f.blocks));
  add("Подвал", C.footer.blocks);
  (C.sections || []).forEach(x => add("Раздел: " + (x.title || "без названия"), x.blocks));
  return out;
}
const NATIVE_NAMES = {hero:"Главный экран", stats:"Статистика (онлайн, 24/7…)", project:"О проекте", features:"Возможности", join:"Присоединиться", rules:"Правила", faq:"FAQ"};
function normLayout() {
  data.sections = data.sections || []; data.layout = data.layout || {};
  const L = data.layout, ids = [...Object.keys(NATIVE_NAMES), ...data.sections.map(x => x.id)];
  L.order = [...new Set([...(L.order || []).filter(x => ids.includes(x)), ...ids])];
  L.hidden = (L.hidden || []).filter(x => ids.includes(x));
  L.colors = L.colors || {};
  [...Object.keys(NATIVE_NAMES), "footer"].forEach(k => { if (typeof L.colors[k] !== "string") L.colors[k] = ""; });
}
function layoutEditor() {
  normLayout();
  const L = data.layout, f = mk("fieldset", "blocks-ed");
  f.append(mk("legend", "", "Структура страницы"));
  f.append(mk("small", "hint", "Порядок разделов на сайте, показ и скрытие, цвет фона, новые разделы. Содержимое существующих разделов редактируется ниже."));
  L.order.forEach((id, i) => {
    const sec = data.sections.find(x => x.id === id);
    const box = mk("fieldset");
    box.append(mk("legend", "", (i + 1) + ". " + (sec ? "Новый раздел: " + (sec.title || "без названия") : NATIVE_NAMES[id])));
    const show = mk("input"); show.type = "checkbox"; show.checked = !L.hidden.includes(id);
    show.onchange = () => { L.hidden = show.checked ? L.hidden.filter(x => x !== id) : [...L.hidden, id]; };
    const chk = mk("label"); chk.append(show, " Показывать на сайте"); box.append(chk);
    box.append(fld("Цвет фона раздела", colorField(sec || L.colors, sec ? "bg" : id)));
    if (sec) {
      box.append(fld("Заголовок раздела", txt(sec, "title")));
      const nav = mk("input"); nav.type = "checkbox"; nav.checked = sec.nav; nav.onchange = () => sec.nav = nav.checked;
      const nl = mk("label"); nl.append(nav, " Ссылка на раздел в меню сайта"); box.append(nl);
      box.append(blocksEditor(sec, "blocks"));
    }
    const t = mk("div", "tools");
    [["↑", () => i > 0 && ([L.order[i-1], L.order[i]] = [L.order[i], L.order[i-1]])],
     ["↓", () => i < L.order.length-1 && ([L.order[i+1], L.order[i]] = [L.order[i], L.order[i+1]])]].forEach(([s, fn]) => {
      const b = mk("button", "mini", s); b.type = "button"; b.onclick = () => { fn(); draw(); }; t.append(b);
    });
    if (sec) {
      const d = mk("button", "mini", "✕ Удалить раздел"); d.type = "button";
      d.onclick = () => { if (confirm("Удалить раздел вместе со всем его содержимым?")) { data.sections.splice(data.sections.indexOf(sec), 1); draw(); } };
      t.append(d);
    }
    box.append(t); f.append(box);
  });
  const add = mk("button", "mini", "+ Новый раздел"); add.type = "button";
  add.onclick = () => { data.sections.push({id: "c" + Date.now().toString(36), title: "", nav: false, bg: "", blocks: []}); draw(); };
  f.append(add, fld("Цвет фона подвала", colorField(L.colors, "footer")));
  return f;
}

function draw() {
  const y = scrollY;
  $("#root").replaceChildren();
  $("#root").append(layoutEditor());
  build($("#root"), data, ORIGINAL);
  scrollTo(0, y);
}

async function open(user) {
  $("#login").hidden = true; $("#panel").hidden = false; $("#who").textContent = user;
  const r = await fetch("/api/content", {cache:"no-store"});
  const j = await r.json();
  if (!r.ok) { $("#msg").textContent = j.error || "Ошибка загрузки содержимого"; $("#msg").style.color = "#ff5a64"; return; }
  ORIGINAL = j;
  data = JSON.parse(JSON.stringify(ORIGINAL));
  draw();
}

async function login() {
  const r = await api("POST", "/api/login", {username:$("#u").value, password:$("#p").value});
  const j = await r.json();
  if (r.ok) open(j.user);
  else $("#err").textContent = j.error || "Ошибка";
}
$("#go").onclick = login;
$("#p").onkeydown = e => { if (e.key === "Enter") login(); };
$("#out").onclick = async () => { await api("POST", "/api/logout"); location.reload(); };
$("#save").onclick = async () => {
  const m = $("#msg"); m.textContent = "Сохраняю…"; m.style.color = "";
  const r = await api("PUT", "/api/content", data), j = await r.json();
  m.textContent = r.ok ? "Сохранено ✓" : (j.error || "Ошибка");
  m.style.color = r.ok ? "#6ee7a0" : "#ff5a64";
  if (r.status === 401) location.reload();
};

api("GET", "/api/me").then(async r => { if (r.ok) open((await r.json()).user); });